import PredictHero from "../componenets/predict-hero/PredictHero";
const Predict = () => {
	return (
		<>
			<PredictHero />
		</>
	);
};

export default Predict;
