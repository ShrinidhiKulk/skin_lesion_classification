import "./Loding.css";

const Loding = () => {
	return <div class="loader"></div>;
};

export default Loding;
